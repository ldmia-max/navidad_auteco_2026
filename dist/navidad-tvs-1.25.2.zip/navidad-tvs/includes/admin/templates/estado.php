<?php
/**
 * Página de estado del concurso.
 *
 * Variables disponibles desde NavidadTVS_Admin::render_estado():
 *
 * @var string               $hoy      Fecha de hoy en la zona del concurso.
 * @var bool                 $abierta  Si la ventana de participación está abierta.
 * @var NavidadTVS_Settings  $settings Configuración.
 *
 * @package NavidadTVS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$database     = NavidadTVS_Plugin::instancia()->database;
$tablas       = $database->estado_tablas();
$total_padron = $database->contar_participantes();
$padron_hoy   = $database->contar_participantes( $hoy );
$scores_hoy   = $database->contar_scores( $hoy );

$nombres_dias = array(
	1 => __( 'Lun', 'navidad-tvs' ),
	2 => __( 'Mar', 'navidad-tvs' ),
	3 => __( 'Mié', 'navidad-tvs' ),
	4 => __( 'Jue', 'navidad-tvs' ),
	5 => __( 'Vie', 'navidad-tvs' ),
	6 => __( 'Sáb', 'navidad-tvs' ),
	7 => __( 'Dom', 'navidad-tvs' ),
);

$dias_activos = array();
foreach ( (array) $settings->get( 'dias_habiles' ) as $d ) {
	if ( isset( $nombres_dias[ $d ] ) ) {
		$dias_activos[] = $nombres_dias[ $d ];
	}
}
?>
<div class="wrap">
	<h1><?php esc_html_e( 'Concurso Navideño TVS', 'navidad-tvs' ); ?></h1>

	<?php
	/*
	 * El aviso del teléfono de pruebas va arriba del todo y en rojo.
	 *
	 * Un número de pruebas olvidado en producción es una puerta abierta: entra
	 * a cualquier hora y repite sin límite. No puede ganar nada, porque sus
	 * carreras no se guardan, pero no tiene por qué seguir ahí cuando el
	 * concurso esté en marcha. Que se vea en la primera pantalla del panel es
	 * lo que hace que alguien se acuerde de quitarlo.
	 */
	?>
	<?php if ( '' !== (string) $settings->get( 'telefono_pruebas' ) ) : ?>
		<div class="notice notice-error">
			<p>
				<strong><?php esc_html_e( 'Hay un teléfono de pruebas activo.', 'navidad-tvs' ); ?></strong>
				<code><?php echo esc_html( $settings->get( 'telefono_pruebas' ) ); ?></code>
			</p>
			<p>
				<?php esc_html_e( 'Ese número entra a cualquier hora y repite sin límite. Sus carreras no se guardan y no puede ganar, pero quítalo en Configuración cuando termines de probar.', 'navidad-tvs' ); ?>
			</p>
		</div>
	<?php endif; ?>

	<?php if ( $settings->get( 'concurso_congelado' ) ) : ?>
		<div class="notice notice-warning">
			<p><strong><?php esc_html_e( 'El concurso está congelado.', 'navidad-tvs' ); ?></strong>
			<?php esc_html_e( 'Nadie puede participar, aunque la hora esté dentro de la ventana.', 'navidad-tvs' ); ?></p>
		</div>
	<?php elseif ( $abierta ) : ?>
		<div class="notice notice-success">
			<p><strong><?php esc_html_e( 'La ventana de participación está abierta.', 'navidad-tvs' ); ?></strong></p>
		</div>
	<?php else : ?>
		<div class="notice notice-info">
			<p><?php esc_html_e( 'La ventana de participación está cerrada en este momento.', 'navidad-tvs' ); ?></p>
		</div>
	<?php endif; ?>

	<?php
	/*
	 * Por qué está cerrado importa tanto como que lo esté. Sin esto, un
	 * concurso que todavía no empieza y uno congelado se ven igual desde
	 * aquí, y se pierde media mañana buscando en el sitio equivocado.
	 */
	$f_inicio = (string) $settings->get( 'fecha_inicio' );
	$f_fin    = (string) $settings->get( 'fecha_fin' );

	if ( ! $abierta && ! $settings->get( 'concurso_congelado' ) ) :
		if ( '' !== $f_inicio && $hoy < $f_inicio ) :
			?>
			<div class="notice notice-info">
				<p>
					<?php
					printf(
						/* translators: %s: fecha de inicio del concurso */
						esc_html__( 'El concurso todavía no empieza: arranca el %s.', 'navidad-tvs' ),
						esc_html( $f_inicio )
					);
					?>
				</p>
			</div>
			<?php
		elseif ( '' !== $f_fin && $hoy > $f_fin ) :
			?>
			<div class="notice notice-info">
				<p>
					<?php
					printf(
						/* translators: %s: fecha final del concurso */
						esc_html__( 'El concurso terminó el %s.', 'navidad-tvs' ),
						esc_html( $f_fin )
					);
					?>
				</p>
			</div>
			<?php
		endif;
	endif;
	?>

	<h2><?php esc_html_e( 'Jornada de hoy', 'navidad-tvs' ); ?></h2>
	<table class="widefat striped" style="max-width:640px">
		<tbody>
			<tr>
				<th scope="row"><?php esc_html_e( 'Fecha (hora Colombia)', 'navidad-tvs' ); ?></th>
				<td><?php echo esc_html( $hoy ); ?></td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Fechas del concurso', 'navidad-tvs' ); ?></th>
				<td>
					<?php
					if ( '' === $f_inicio && '' === $f_fin ) {
						echo '<em>' . esc_html__( 'sin rango: cualquier día hábil', 'navidad-tvs' ) . '</em>';
					} else {
						printf(
							/* translators: 1: fecha de inicio, 2: fecha final */
							esc_html__( '%1$s a %2$s', 'navidad-tvs' ),
							esc_html( '' !== $f_inicio ? $f_inicio : __( 'sin tope', 'navidad-tvs' ) ),
							esc_html( '' !== $f_fin ? $f_fin : __( 'sin tope', 'navidad-tvs' ) )
						);
					}
					?>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Horario', 'navidad-tvs' ); ?></th>
				<td>
					<?php
					printf(
						/* translators: 1: hora de inicio, 2: hora de fin, 3: días hábiles */
						esc_html__( '%1$s a %2$s · %3$s', 'navidad-tvs' ),
						esc_html( $settings->get( 'hora_inicio' ) ),
						esc_html( $settings->get( 'hora_fin' ) ),
						esc_html( implode( ', ', $dias_activos ) )
					);
					?>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Habilitados hoy', 'navidad-tvs' ); ?></th>
				<td><?php echo esc_html( number_format_i18n( $padron_hoy ) ); ?></td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Ya participaron hoy', 'navidad-tvs' ); ?></th>
				<td><?php echo esc_html( number_format_i18n( $scores_hoy ) ); ?></td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Premios por jornada', 'navidad-tvs' ); ?></th>
				<td><?php echo esc_html( number_format_i18n( (int) $settings->get( 'premios_por_jornada' ) ) ); ?></td>
			</tr>
		</tbody>
	</table>

	<h2><?php esc_html_e( 'Padrón', 'navidad-tvs' ); ?></h2>
	<p>
		<?php
		printf(
			/* translators: %s: total de participantes en el padrón */
			esc_html__( 'Total de participantes importados: %s', 'navidad-tvs' ),
			'<strong>' . esc_html( number_format_i18n( $total_padron ) ) . '</strong>'
		);
		?>
	</p>

	<h2><?php esc_html_e( 'Estado de las tablas', 'navidad-tvs' ); ?></h2>
	<table class="widefat striped" style="max-width:640px">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Tabla', 'navidad-tvs' ); ?></th>
				<th><?php esc_html_e( 'Estado', 'navidad-tvs' ); ?></th>
			</tr>
		</thead>
		<tbody>
		<?php foreach ( $tablas as $nombre => $existe ) : ?>
			<tr>
				<td><code><?php echo esc_html( $nombre ); ?></code></td>
				<td>
					<?php if ( $existe ) : ?>
						<span style="color:#1a7f37">&#10003; <?php esc_html_e( 'creada', 'navidad-tvs' ); ?></span>
					<?php else : ?>
						<span style="color:#b32d2e">&#10007; <?php esc_html_e( 'falta', 'navidad-tvs' ); ?></span>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>

	<p class="description">
		<?php
		printf(
			/* translators: %s: versión del plugin */
			esc_html__( 'Versión del plugin: %s', 'navidad-tvs' ),
			esc_html( NAVIDAD_TVS_VERSION )
		);
		?>
	</p>
</div>
