<?php
/**
 * Página de acceso al juego, con la ventana de participación abierta.
 *
 * Variables desde NavidadTVS_Shortcode::render():
 *
 * @var array  $estado   Estado de la ventana.
 * @var string $url_tyc  Enlace a términos y condiciones.
 * @var string $url_faq  Enlace a preguntas frecuentes.
 * @var string $site_key Clave pública de Turnstile, o cadena vacía.
 *
 * @package NavidadTVS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="ntvs" id="ntvs-app">

	<!-- Formulario ----------------------------------------------------- -->
	<div class="ntvs-panel ntvs-panel--acceso" id="ntvs-panel-acceso">
		<p class="ntvs-panel__intro"><?php esc_html_e( 'Ingresa tus datos para entrar al juego', 'navidad-tvs' ); ?></p>

		<form class="ntvs-form" id="ntvs-form" novalidate>

			<div class="ntvs-campo">
				<label class="ntvs-label" for="ntvs-nombre"><?php esc_html_e( 'Tu nombre', 'navidad-tvs' ); ?></label>
				<input
					class="ntvs-input"
					type="text"
					id="ntvs-nombre"
					name="nombre"
					maxlength="60"
					autocomplete="name"
					autocapitalize="words"
					required>
			</div>

			<div class="ntvs-campo">
				<label class="ntvs-label" for="ntvs-telefono"><?php esc_html_e( 'Tu celular', 'navidad-tvs' ); ?></label>
				<input
					class="ntvs-input"
					type="tel"
					id="ntvs-telefono"
					name="telefono"
					inputmode="numeric"
					pattern="[0-9]*"
					maxlength="14"
					placeholder="3001234567"
					autocomplete="tel-national"
					required>
				<p class="ntvs-ayuda"><?php esc_html_e( 'Diez dígitos, el mismo que registraste al comprar tu moto.', 'navidad-tvs' ); ?></p>
			</div>

			<div class="ntvs-campo ntvs-campo--check">
				<label class="ntvs-check">
					<input type="checkbox" id="ntvs-acepta" name="acepta" value="1" required>
					<span>
						<?php
						printf(
							/* translators: %s: enlace a los términos y condiciones */
							esc_html__( 'Acepto los %s y el tratamiento de mis datos personales.', 'navidad-tvs' ),
							'<a href="' . esc_url( $url_tyc ) . '" target="_blank" rel="noopener">' . esc_html__( 'términos y condiciones', 'navidad-tvs' ) . '</a>'
						);
						?>
					</span>
				</label>
			</div>

			<?php if ( '' !== $site_key ) : ?>
				<div class="cf-turnstile" data-sitekey="<?php echo esc_attr( $site_key ); ?>" data-theme="dark"></div>
			<?php endif; ?>

			<p class="ntvs-error" id="ntvs-error" role="alert" aria-live="assertive" hidden></p>

			<button class="ntvs-boton ntvs-boton--relieve" type="submit" id="ntvs-enviar">
				<?php esc_html_e( 'Entrar al juego', 'navidad-tvs' ); ?>
			</button>
		</form>

		<p class="ntvs-aviso">
			<?php esc_html_e( 'Tienes un solo intento. Juega desde una conexión estable, preferiblemente WiFi.', 'navidad-tvs' ); ?>
		</p>

		<p class="ntvs-enlaces">
			<a href="<?php echo esc_url( $url_faq ); ?>"><?php esc_html_e( 'Preguntas frecuentes', 'navidad-tvs' ); ?></a>
			<span aria-hidden="true">·</span>
			<a href="<?php echo esc_url( $url_tyc ); ?>"><?php esc_html_e( 'Términos y condiciones', 'navidad-tvs' ); ?></a>
		</p>
	</div>

	<?php include NAVIDAD_TVS_PATH . 'templates/user/parcial-instrucciones.php'; ?>

	<!-- Juego ------------------------------------------------------------ -->
	<div class="ntvs-panel ntvs-panel--juego" id="ntvs-panel-juego" hidden>
		<div id="ntvs-game-root" class="ntvs-game-root"></div>

		<!--
			Mando en pantalla, según imagenes_apoyo/control.png.

			Carcasa clara con el panel negro dentro: cruceta a la izquierda,
			rejilla decorativa al centro y las dos acciones a la derecha.

			Antes los controles eran cuatro cuadrantes invisibles sobre el propio
			juego y no había forma de adivinarlos. Con un solo intento por
			persona, adivinar no es una opción.

			Los botones son <button> de verdad, así que el teclado los alcanza con
			Tab y el lector de pantalla los anuncia. La rejilla del centro es
			adorno y va oculta para quien no la ve.
		-->
		<div class="ntvs-mando" id="ntvs-mando" hidden>
			<div class="ntvs-mando__panel">

				<div class="ntvs-mando__cruceta">
					<button class="ntvs-btn ntvs-btn--dir" type="button" data-mando="arriba"
						aria-label="<?php esc_attr_e( 'Subir de carril', 'navidad-tvs' ); ?>">
						<span class="ntvs-flecha ntvs-flecha--arriba" aria-hidden="true"></span>
					</button>
					<button class="ntvs-btn ntvs-btn--dir" type="button" data-mando="abajo"
						aria-label="<?php esc_attr_e( 'Bajar de carril', 'navidad-tvs' ); ?>">
						<span class="ntvs-flecha ntvs-flecha--abajo" aria-hidden="true"></span>
					</button>
				</div>

				<div class="ntvs-mando__rejilla" aria-hidden="true">
					<span class="ntvs-ranura ntvs-ranura--marca"><?php esc_html_e( 'CONTROL', 'navidad-tvs' ); ?></span>
				</div>

				<div class="ntvs-mando__acciones">
					<button class="ntvs-btn ntvs-btn--turbo" type="button" data-mando="turbo"
						aria-label="<?php esc_attr_e( 'Turbo', 'navidad-tvs' ); ?>">
						<?php esc_html_e( 'TURBO', 'navidad-tvs' ); ?>
					</button>
					<button class="ntvs-btn ntvs-btn--acelera" type="button" data-mando="acelera"
						aria-label="<?php esc_attr_e( 'Acelerar', 'navidad-tvs' ); ?>">
						<?php esc_html_e( 'ACELERAR', 'navidad-tvs' ); ?>
					</button>
				</div>

			</div>
		</div>

		<!-- Resultado. La distancia que vale es la que confirma el servidor. -->
		<div class="ntvs-resultado" id="ntvs-resultado" hidden>
			<p class="ntvs-resultado__titulo"><?php esc_html_e( 'Carrera terminada', 'navidad-tvs' ); ?></p>
			<p class="ntvs-resultado__nombre" id="ntvs-res-nombre"></p>
			<p class="ntvs-resultado__distancia" id="ntvs-res-distancia"></p>

			<ul class="ntvs-resultado__detalle">
				<li><?php esc_html_e( 'Llaves', 'navidad-tvs' ); ?> <span id="ntvs-res-logos"></span></li>
				<li><?php esc_html_e( 'Caídas', 'navidad-tvs' ); ?> <span id="ntvs-res-caidas"></span></li>
				<li><?php esc_html_e( 'Veces que se sobrecalentó', 'navidad-tvs' ); ?> <span id="ntvs-res-sobrecal"></span></li>
			</ul>

			<!--
				Estado del envío. Mientras no diga que el resultado quedó
				registrado, el participante no puede irse tranquilo: el intento
				es único y lo que no llega al servidor no existe.
			-->
			<p class="ntvs-envio" id="ntvs-envio" role="status" aria-live="polite"></p>

			<button class="ntvs-boton ntvs-boton--secundario" type="button" id="ntvs-reintentar" hidden>
				<?php esc_html_e( 'Reintentar envío', 'navidad-tvs' ); ?>
			</button>

			<p class="ntvs-resultado__gracias" id="ntvs-res-gracias" hidden><?php esc_html_e( '¡Gracias por participar!', 'navidad-tvs' ); ?></p>
		</div>
	</div>

</div>
